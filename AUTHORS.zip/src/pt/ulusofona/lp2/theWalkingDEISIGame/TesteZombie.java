package pt.ulusofona.lp2.theWalkingDEISIGame;

import org.junit.Test;

public class TesteZombie {



    }

